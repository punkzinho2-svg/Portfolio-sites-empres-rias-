# Portfólio Web — Punkzinho

Portfólio com cinco demonstrações de sites empresariais, cada uma com identidade visual, conteúdo e estrutura próprios.

## Projetos

| Projeto | Segmento | Demonstração |
|---|---|---|
| Norte Studio | Agência de marketing | `sites/agencia-norte/` |
| Casa Oliva | Restaurante | `sites/casa-oliva/` |
| Vértice Imóveis | Imobiliária | `sites/vertice-imoveis/` |
| Linha Arquitetura | Arquitetura e interiores | `sites/linha-arquitetura/` |
| Garagem 47 | Centro automotivo | `sites/garagem-47/` |

## Como visualizar

Abra `index.html` no navegador. Para publicar, envie todos os arquivos para um repositório GitHub e ative **Settings → Pages → Deploy from a branch → main / root**.

## Tecnologias

- HTML5 semântico
- CSS3 responsivo
- Layout adaptável para celular e desktop
- Sem dependências externas ou build obrigatório

## Observação

São demonstrações conceituais para portfólio. Nomes, e-mails, serviços e informações comerciais são fictícios. Não representam clientes reais nem serviços já contratados. Substitua os dados de contato antes de usar comercialmente.

## Licença

MIT — consulte o arquivo `LICENSE`.
